#include"LinkedList.h"

LinkedList::LinkedList()
{
	head = NULL; 
	tail = NULL;
	current = NULL;
}

LinkedList::~LinkedList()
{
	Clear();
}


void LinkedList::Push_back(int x)
{
	//TODO: add a new node to the back of the list with value x
	Node* n = new Node; // create a node n
	n->value = x; // put data to the node
	n->next = NULL; //since ie will be the last element
	
	if (head != NULL) {
		current = head;
		while (current->next != NULL) {
			current = current->next;	
		}
		current->next = n;	
	}
	else { //dont have a list then just put the value head->n
		head = n;
	}
	

}

void LinkedList::Push_front(int x)
{
	//TODO: add a new node to the front of the list with value x
	Node* n = new Node; // create a node n
	n->value = x; // put data to the node
	n->next = head; //since ie will be the last element

	 //dont have a list then just put the value head->n
		head = n;
}

void LinkedList::Insert(int index, int x)
{
	//TODO: add a new node at position "index" of the list with value x
	Node* del = new Node;// = NULL;
	Node* pre = new Node;
	tail = head;
	current = head;
	int i;

	if (index == 0 && head != NULL) {
		Push_front(x);
	}
	else if (head == NULL) {
		Push_back(x);
	}
	else {
		for (i = 0; i < index; i++) {
			pre = current;  // previous 
			current = current->next;			
		}
		pre->next = del; del->value = x;
		del->next = current; current = del;
    }

}

void LinkedList::Delete(int index)
{
	//TODO: delete the node at position "index"
	Node* del = NULL;
	tail = head;
	current = head; 
	int i = 0;
	
		if (index == 0 && head!=NULL) {
			current = current->next;
			head = current;
		}
		else if(head!=NULL){
			for (i = 0; i <= index; i++) {
				current = current->next;
				if (i == index) {
					del = current;
					tail->next = current;
					delete del;
				}
			}
		}
}

void LinkedList::Reverse()
{
	//TODO: reverse all elements in the list
	current = head;
	Node* pre = new Node; pre = NULL;
	Node* next = new Node; next = NULL;
	while (current != NULL) {
		next = current->next;
		current->next = pre;
		pre = current;
		current = next;
	}
	head = pre;
}

void LinkedList::Print()
{
	//TODO: print out all elements in the list
	current = head;
	cout << "List : ";
	while (current!=NULL) {
		cout  << current->value << " ";
		current = current->next;
		//
	}
	cout << endl;
}

void LinkedList::Clear() 
{
	//TODO: delete all elements in the list
	current = head; 
	//Node* del;
	//cout << "List : ";
	while(current->next!=0){
		current = current->next;
		head = current;
	}
	// to remove th last element
	current = current->next;
	head = current;
		//cout << current->value << " ";
	cout << "empty ";
		//
	
}